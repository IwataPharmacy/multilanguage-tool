'use client';
import { RxItem } from '@/types';

const KEY = 'rx_items';

export function loadItems(): RxItem[] {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) as RxItem[] : [];
  } catch { return []; }
}

export function saveItems(items: RxItem[]) {
  localStorage.setItem(KEY, JSON.stringify(items));
}
