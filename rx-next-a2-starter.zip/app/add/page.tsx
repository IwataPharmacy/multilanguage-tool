'use client';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { RxItem, DoseSlot } from '@/types';
import { loadItems, saveItems } from '@/lib/storage';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select } from '@/components/ui/select';

const DRUG_CLASSES = ['解熱鎮痛薬','抗菌薬','胃薬','降圧薬','抗アレルギー薬','気管支拡張薬'];
const NOTE_TEMPLATES = ['食後に服用してください','眠気に注意してください','アルコールは控えてください','抗菌薬は指示日数すべて服用してください','妊娠・授乳中は医師に相談してください'];
const SLOTS: { key: DoseSlot, label: string }[] = [
  { key: 'morning', label: '朝 🌞' },
  { key: 'noon', label: '昼 ☀' },
  { key: 'evening', label: '夜 🌙' },
  { key: 'bedtime', label: '寝る前 🌜' }
];

export default function AddPage() {
  const router = useRouter();
  const [drugClass, setDrugClass] = useState(DRUG_CLASSES[0]);
  const [timesPerDay, setTimesPerDay] = useState<1|2|3|4>(3);
  const [days, setDays] = useState(5);
  const [slots, setSlots] = useState<DoseSlot[]>(['morning','noon','evening']);
  const [notes, setNotes] = useState<string[]>([]);
  const [memo, setMemo] = useState('');

  // timesPerDay変更時、デフォルトのスロットを提案
  useEffect(() => {
    const map: Record<number, DoseSlot[]> = {
      1: ['bedtime'],
      2: ['morning','evening'],
      3: ['morning','noon','evening'],
      4: ['morning','noon','evening','bedtime']
    };
    setSlots(map[timesPerDay]);
  }, [timesPerDay]);

  const toggleNote = (n: string) => {
    setNotes(prev => prev.includes(n) ? prev.filter(x => x !== n) : [...prev, n]);
  };
  const toggleSlot = (s: DoseSlot) => {
    setSlots(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);
  };

  const onAdd = () => {
    const items = loadItems();
    const item: RxItem = {
      id: crypto.randomUUID(),
      drugClass,
      timesPerDay,
      slots,
      days,
      notes,
      memo: memo.trim() || undefined
    };
    saveItems([item, ...items]);
    router.push('/counsel');
  };

  const onCancel = () => router.push('/counsel');

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">薬剤を追加</h1>
      <Card>
        <CardHeader><CardTitle>基本情報</CardTitle></CardHeader>
        <CardContent className="grid gap-3">
          <div>
            <Label className="mb-1 block">薬剤の種類（薬効）</Label>
            <Select value={drugClass} onChange={(e)=>setDrugClass(e.target.value)}>
              {DRUG_CLASSES.map(d => <option key={d} value={d}>{d}</option>)}
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="mb-1 block">1日回数</Label>
              <Select value={timesPerDay} onChange={(e)=>setTimesPerDay(Number(e.target.value) as 1|2|3|4)}>
                <option value={1}>1回</option>
                <option value={2}>2回</option>
                <option value={3}>3回</option>
                <option value={4}>4回</option>
              </Select>
            </div>
            <div>
              <Label className="mb-1 block">日数</Label>
              <Input type="number" min={1} value={days} onChange={(e)=>setDays(Number(e.target.value)||1)} />
            </div>
          </div>

          <div>
            <Label className="mb-1 block">服用タイミング</Label>
            <div className="grid grid-cols-2 gap-2">
              {SLOTS.map(s => (
                <label key={s.key} className="flex items-center gap-2">
                  <input type="checkbox" checked={slots.includes(s.key)} onChange={()=>toggleSlot(s.key)} />
                  <span>{s.label}</span>
                </label>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>定型文 / メモ</CardTitle></CardHeader>
        <CardContent className="grid gap-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {NOTE_TEMPLATES.map(n => (
              <label key={n} className="flex items-center gap-2">
                <input type="checkbox" checked={notes.includes(n)} onChange={()=>toggleNote(n)} />
                <span>{n}</span>
              </label>
            ))}
          </div>
          <div>
            <Label className="mb-1 block">メモ</Label>
            <Textarea value={memo} onChange={(e)=>setMemo(e.target.value)} placeholder="患者さん向けメモや注意点を入力" />
          </div>
        </CardContent>
      </Card>

      <div className="sticky bottom-4 bg-slate-50/80 backdrop-blur rounded-2xl p-2 border border-slate-200 flex gap-2 justify-end">
        <Button variant="outline" onClick={onCancel}>キャンセル</Button>
        <Button onClick={onAdd}>追加</Button>
      </div>
    </div>
  );
}
