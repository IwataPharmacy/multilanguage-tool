'use client';
import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function Home() {
  return (
    <div className="min-h-[70vh] grid place-items-center">
      <Card className="max-w-md w-full">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-2">
            <Image src="/logo.svg" width={72} height={72} alt="logo" />
          </div>
          <CardTitle>外国人向け 服薬指導支援</CardTitle>
        </CardHeader>
        <CardContent className="text-center">
          <Link href="/counsel">
            <Button size="lg">服薬指導を開始</Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
