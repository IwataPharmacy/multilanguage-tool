'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { RxItem } from '@/types';
import { loadItems, saveItems } from '@/lib/storage';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Trash2 } from 'lucide-react';

const SLOT_ICON: Record<string, string> = { morning: '🌞', noon: '☀', evening: '🌙', bedtime: '🌜' };

export default function CounselPage() {
  const [items, setItems] = useState<RxItem[]>([]);

  useEffect(() => { setItems(loadItems()); }, []);
  useEffect(() => { saveItems(items); }, [items]);

  const remove = (id: string) => setItems(prev => prev.filter(i => i.id !== id));

  return (
    <div className="space-y-4">
      <div className="row justify-between">
        <h1 className="text-xl font-semibold">服薬指導</h1>
        <Link href="/add"><Button>薬剤を追加</Button></Link>
      </div>

      {items.length === 0 && <p className="text-slate-500">まだ薬剤がありません。「薬剤を追加」を押してください。</p>}

      <div className="grid gap-3">
        {items.map(it => (
          <Card key={it.id}>
            <CardHeader className="row justify-between">
              <CardTitle>{it.drugClass}</CardTitle>
              <Button variant="outline" onClick={() => remove(it.id)} aria-label="削除">
                <Trash2 className="w-4 h-4 mr-1" /> 削除
              </Button>
            </CardHeader>
            <CardContent className="space-y-1">
              <div><span className="badge">{it.timesPerDay}回/日</span>
                   <span className="badge">{it.days}日分</span></div>
              <div><b>服用タイミング：</b>{it.slots.map(s => SLOT_ICON[s]).join(' ')}</div>
              {it.notes.length > 0 && <div><b>定型文：</b>{it.notes.join(' / ')}</div>}
              {it.memo && <div><b>メモ：</b>{it.memo}</div>}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="py-2">
        <Link href="/add"><Button variant="outline" className="w-full">＋ 薬剤を追加</Button></Link>
      </div>
    </div>
  );
}
