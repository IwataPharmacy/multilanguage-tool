export type Lang = 'en' | 'pt' | 'es' | 'zh-CN' | 'vi-VN' | 'ne-NP' | 'ko-KR' | 'ja';

export type DoseSlot = 'morning' | 'noon' | 'evening' | 'bedtime';

export type RxItem = {
  id: string;
  drugClass: string;          // 薬剤の種類/薬効
  timesPerDay: 1 | 2 | 3 | 4; // 服用回数
  slots: DoseSlot[];          // 服用タイミング
  days: number;               // 服用日数
  notes: string[];            // 定型文
  memo?: string;              // メモ
};
